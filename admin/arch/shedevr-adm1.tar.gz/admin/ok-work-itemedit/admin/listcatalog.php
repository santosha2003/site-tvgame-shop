<?
require_once("./auth.php");

if (!isset($_POST['mode'])) $_POST['mode']="";
switch($_POST['mode']) {
  case "start":
         if(isset($kod1c)){
          $a=$kod1c;
           $z=$id;
           $q=count($a);
          for($i=0;$i<$q;$i++){

     $db -> query("UPDATE items SET kod1c='$a[$i]' WHERE id='$z[$i]'");

         }
         }
     if(isset($price)){
          $a=$price;
           $z=$id;
           $q=count($a);
          for($i=0;$i<$q;$i++){

     $db -> query("UPDATE items SET price='$a[$i]' WHERE id='$z[$i]'");

         }
         }

     Header("Location: index.php?op=select&mode=listcatalog");
      break;
     }




if (!isset($_GET['mode'])) $_GET['mode']="";
        switch($_GET['mode']) {

  case "listcatalog":
  $tmpl -> loadTemplatefile("listcatalog.inc",true,true);

        $res = $db -> query("SELECT id,name FROM category WHERE status='Y' ORDER BY updown");
if($res -> numRows()) {
  while($row = $res -> fetchRow()) {
       $tmpl -> setCurrentBlock("list_items_cat1");
       $tmpl -> setVariable($row);
       $tmpl -> parseCurrentBlock("list_items_cat1");
         }
         }
      break;

     case "listselect":

       $tmpl -> loadTemplatefile("listselect.inc",true,true);
       $res = $db -> query("SELECT name FROM category WHERE id='$_GET[id]'");
        if($res -> numRows()) {
       while($rows = $res -> fetchRow()){
       $tmpl -> setCurrentBlock("list_cat");
       $tmpl -> setVariable($rows);
       $tmpl -> parseCurrentBlock("list_cat");
         }
         }

       $result = $db -> query("SELECT * FROM items WHERE cid='$_GET[id]'");
       if($result -> numRows()) {
       while($row1 = $result -> fetchRow()){

       $tmpl -> setCurrentBlock("list_items");
       $tmpl -> setVariable($row1);
       $tmpl -> parseCurrentBlock("list_items");
               }
                }

    $rest = $db -> query("SELECT id,name FROM category WHERE status='Y' ORDER BY updown");
if($rest -> numRows()) {
  while($rowt = $rest -> fetchRow()) {
       $tmpl -> setCurrentBlock("list_items_cat1");
       $tmpl -> setVariable($rowt);
       $tmpl -> parseCurrentBlock("list_items_cat1");
         }
         }
    break;
   }

?>