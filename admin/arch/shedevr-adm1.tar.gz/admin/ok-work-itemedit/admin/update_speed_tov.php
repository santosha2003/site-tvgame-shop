<?
require_once("./auth.php");
 $tmpl -> loadTemplatefile("update_speed_tov.inc",true,true);
  switch($_POST[mode]) {
  case "start":
         if(isset($kod1c)){
          $a=$kod1c;
           $z=$id;
           $q=count($a);
          for($i=0;$i<$q;$i++){

     $db -> query("UPDATE items SET kod1c='$a[$i]' WHERE id='$z[$i]'");

         }
         }
     if(isset($price)){
          $a=$price;
           $z=$id;
           $q=count($a);
          for($i=0;$i<$q;$i++){

     $db -> query("UPDATE items SET price='$a[$i]' WHERE id='$z[$i]'");

         }
         }

     Header("Location: index.php?op=update_speed_tov");
      break;
      default:




       $result = $db -> query("SELECT id,cid,name,mark,model,sku,kod1c,price FROM items");
       if($result -> numRows()) {
       while($row1 = $result -> fetchRow()){

       $tmpl -> setCurrentBlock("list_items");
       $tmpl -> setVariable($row1);
       $tmpl -> parseCurrentBlock("list_items");
               }
                }

        

   }

?>